#!/bin/sh
# Insert any extra commands you need to run here
python3 server.py
